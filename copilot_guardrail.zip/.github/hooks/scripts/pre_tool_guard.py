#!/usr/bin/env python3
"""
Conservative GitHub Copilot CLI preToolUse guardrail.

Design:
- DENY operations that are destructive, history-rewriting, secret-seeking, or
  obvious attempts to bypass/modify this guardrail.
- ASK for broad/high-risk shell operations where intent is ambiguous.
- ALLOW ordinary read/search/build/edit operations.
- False positives are intentional. Prune rules to fit the project.

This complements AGENTS.md; it does not replace it.
"""

import json
import os
import re
import sys

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def emit(decision, reason=None):
    out = {"permissionDecision": decision}
    if reason:
        out["permissionDecisionReason"] = reason
    print(json.dumps(out, separators=(",", ":")))
    sys.exit(0)

def deny(reason):
    emit("deny", reason)

def ask(reason):
    emit("ask", reason)

def norm(s):
    return re.sub(r"\s+", " ", str(s or "")).strip()

def args_object(raw):
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else {"raw": raw}
        except Exception:
            return {"raw": raw}
    return {"raw": raw}

def command_from(args):
    for key in ("command", "cmd", "script", "raw"):
        if key in args and isinstance(args[key], str):
            return args[key]
    return json.dumps(args, separators=(",", ":"), ensure_ascii=False)

def path_strings(obj):
    """Recursively collect strings that look like path-bearing tool arguments."""
    found = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            lk = str(k).lower()
            if isinstance(v, str) and any(x in lk for x in
                    ("path", "file", "target", "source", "destination", "cwd")):
                found.append(v)
            else:
                found.extend(path_strings(v))
    elif isinstance(obj, list):
        for v in obj:
            found.extend(path_strings(v))
    return found

def matches_any(text, patterns):
    return any(re.search(p, text, re.I | re.S) for p in patterns)

# ---------------------------------------------------------------------------
# Input
# ---------------------------------------------------------------------------

try:
    event = json.load(sys.stdin)
except Exception as exc:
    # preToolUse command-hook errors fail closed, but emit a useful reason too.
    deny(f"Guardrail could not parse hook input: {exc}")

tool = str(event.get("toolName") or event.get("tool_name") or "")
args = args_object(event.get("toolArgs", event.get("tool_input", {})))
cmd = norm(command_from(args))
cmd_l = cmd.lower()

# ---------------------------------------------------------------------------
# Guard the guardrail itself.
# ---------------------------------------------------------------------------

PROTECTED_PATHS = (
    ".github/hooks",
    ".github/copilot/settings.json",
    ".github/copilot/settings.local.json",
    "agents.md",
)

paths = [p.replace("\\", "/").lower() for p in path_strings(args)]
if tool in {"edit", "create"} and any(
    protected in p for p in paths for protected in PROTECTED_PATHS
):
    deny("Policy/guardrail files are protected from agent modification.")

# Shell attempts to modify/delete guardrail or policy files.
if tool in {"bash", "powershell"} and any(p in cmd_l for p in PROTECTED_PATHS):
    # Reading these files is useful and expected; deny only when write/destructive
    # syntax is also present.
    if matches_any(cmd, [
        r"\b(rm|unlink|truncate|mv|cp|install|sed\s+-i|perl\s+-pi|tee)\b",
        r"(?:^|[;&|]\s*)[^;&|]*(?:>|>>)\s*[^;&|]*",
        r"\b(remove-item|move-item|copy-item|set-content|add-content|clear-content|out-file)\b",
        r"\bpython(?:3)?\b.*(?:write|unlink|remove|rename|replace)",
    ]):
        deny("Attempt to modify or remove AGENTS.md or Copilot guardrail configuration.")

# ---------------------------------------------------------------------------
# Git: history, refs, worktree, remote state
# ---------------------------------------------------------------------------

DENY_GIT = [
    # Working tree/index destruction.
    r"\bgit\s+reset\b",
    r"\bgit\s+clean\b",
    r"\bgit\s+restore\b",
    r"\bgit\s+checkout\b",
    # History rewriting / commit replacement.
    r"\bgit\s+rebase\b",
    r"\bgit\s+commit\b[^\n;&|]*\s--amend\b",
    r"\bgit\s+(?:filter-branch|filter-repo|replace)\b",
    r"\bgit\s+cherry-pick\b",
    r"\bgit\s+revert\b",
    # Ref deletion / forced ref movement.
    r"\bgit\s+branch\b[^\n;&|]*\s-[dD]\b",
    r"\bgit\s+tag\b[^\n;&|]*\s-d\b",
    r"\bgit\s+update-ref\b",
    r"\bgit\s+symbolic-ref\b",
    # Reflog/object destruction.
    r"\bgit\s+reflog\b[^\n;&|]*\b(?:expire|delete)\b",
    r"\bgit\s+(?:gc|prune)\b",
    # Stash can hide/drop user work; intentionally conservative.
    r"\bgit\s+stash\b",
    # Remote destructive operations.
    r"\bgit\s+push\b[^\n;&|]*(?:--force-with-lease|--force|-f)\b",
    r"\bgit\s+push\b[^\n;&|]*\s--delete\b",
    r"\bgit\s+push\b[^\n;&|]*\s:[^\s]+",
    r"\bgit\s+remote\s+(?:remove|rm|set-url)\b",
]

if tool in {"bash", "powershell"} and matches_any(cmd, DENY_GIT):
    deny("Blocked destructive or history-altering Git operation.")

# Committing/pushing are not inherently destructive, but AGENTS.md requires
# explicit approval. Force the CLI to ask every time.
ASK_GIT = [
    r"\bgit\s+commit\b",
    r"\bgit\s+push\b",
    r"\bgit\s+merge\b",
    r"\bgit\s+pull\b",
]
if tool in {"bash", "powershell"} and matches_any(cmd, ASK_GIT):
    ask("Git operation requires explicit user approval.")

# ---------------------------------------------------------------------------
# Filesystem/data destruction
# ---------------------------------------------------------------------------

DENY_FS = [
    # Unix deletion/destructive primitives.
    r"(?:^|[;&|]\s*)\s*(?:sudo\s+)?rm\b",
    r"(?:^|[;&|]\s*)\s*(?:sudo\s+)?rmdir\b",
    r"(?:^|[;&|]\s*)\s*unlink\b",
    r"(?:^|[;&|]\s*)\s*shred\b",
    r"(?:^|[;&|]\s*)\s*truncate\b",
    # PowerShell / Windows deletion.
    r"\bremove-item\b",
    r"\bclear-content\b",
    r"\bdel(?:ete)?\b",
    r"\berase\b",
    # Destructive filesystem/disk/system operations.
    r"\bmkfs(?:\.[a-z0-9]+)?\b",
    r"\bdd\b[^\n;&|]*\bof=",
    r"\b(?:fdisk|parted|wipefs)\b",
    r"\bformat(?:\.com)?\b",
    r"\bmount\b|\bumount\b",
    # Recursive permission/ownership changes.
    r"\bchmod\b[^\n;&|]*\s-[^\s]*R",
    r"\bchown\b[^\n;&|]*\s-[^\s]*R",
    r"\bchmod\s+-R\b",
    r"\bchown\s+-R\b",
]
if tool in {"bash", "powershell"} and matches_any(cmd, DENY_FS):
    deny("Blocked filesystem/data-destructive operation.")

# Broad overwrite/redirection is ambiguous: ask rather than silently allow.
ASK_OVERWRITE = [
    r"(?:^|[;&|]\s*)[^;&|]*(?<!>)>(?!>)[^=]",  # shell overwrite redirection
    r"\btee\b(?![^\n;&|]*\s-a\b)",
    r"\bset-content\b",
    r"\bout-file\b(?![^\n;&|]*-append\b)",
    r"\bcopy-item\b[^\n;&|]*-force\b",
    r"\bmove-item\b[^\n;&|]*-force\b",
    r"\bcp\b[^\n;&|]*\s-f\b",
    r"\bmv\b[^\n;&|]*\s-f\b",
]
if tool in {"bash", "powershell"} and matches_any(cmd, ASK_OVERWRITE):
    ask("Command may overwrite existing data; explicit approval required.")

# ---------------------------------------------------------------------------
# Secrets, credentials, sensitive host/user state
# ---------------------------------------------------------------------------

SENSITIVE = [
    r"(?:^|[/\\])\.ssh(?:[/\\]|$)",
    r"(?:^|[/\\])\.aws(?:[/\\]|$)",
    r"(?:^|[/\\])\.gnupg(?:[/\\]|$)",
    r"(?:^|[/\\])\.kube(?:[/\\]|$)",
    r"(?:^|[/\\])\.docker(?:[/\\]|$)",
    r"(?:^|[/\\])\.config[/\\]gh(?:[/\\]|$)",
    r"(?:^|[/\\])\.copilot(?:[/\\]|$)",
    r"\bid_rsa\b|\bid_ed25519\b",
    r"\bcredentials(?:\.json)?\b",
    r"\.env(?:\.[A-Za-z0-9_.-]+)?\b",
    r"\b(?:keychain|credential manager|credential-manager|secretservice)\b",
    r"\b(?:printenv|env)\b",
    r"\b(?:set|export)\b[^\n;&|]*(?:TOKEN|SECRET|PASSWORD|PASSWD|API_KEY|PRIVATE_KEY)",
]
if tool in {"bash", "powershell", "view", "grep", "glob"}:
    combined = cmd + " " + " ".join(paths)
    if matches_any(combined, SENSITIVE):
        deny("Blocked access to likely credentials, secrets, or sensitive configuration.")

# Explicit environment dumping is too likely to expose tokens.
if tool in {"bash", "powershell"} and matches_any(cmd, [
    r"(?:^|[;&|]\s*)\s*(?:printenv|env)\s*(?:$|[;&|])",
    r"\bget-childitem\s+env:",
    r"\bdir\s+env:",
]):
    deny("Blocked broad environment-variable dump.")

# ---------------------------------------------------------------------------
# Privilege escalation, host/container escape, service control
# ---------------------------------------------------------------------------

DENY_PRIV = [
    r"(?:^|[;&|]\s*)\s*sudo\b",
    r"(?:^|[;&|]\s*)\s*su\b",
    r"\bnsenter\b",
    r"\bunshare\b",
    r"\bchroot\b",
    r"\bdocker\b",
    r"\bpodman\b",
    r"\bkubectl\b",
    r"/var/run/docker\.sock",
    r"\bsystemctl\b",
    r"\bservice\b",
    r"\bshutdown\b|\breboot\b|\bpoweroff\b|\bhalt\b",
]
if tool in {"bash", "powershell"} and matches_any(cmd, DENY_PRIV):
    deny("Blocked privilege escalation, container/host control, or system-service operation.")

# ---------------------------------------------------------------------------
# Network / package installation / arbitrary remote execution
# ---------------------------------------------------------------------------

# Network destinations and software installation require approval under AGENTS.md.
ASK_NETWORK = [
    r"\b(?:curl|wget|ssh|scp|sftp|rsync|nc|ncat|netcat|telnet)\b",
    r"\b(?:apt|apt-get|dnf|yum|apk|pacman|brew)\b",
    r"\b(?:pip|pip3|uv|poetry)\s+install\b",
    r"\b(?:npm|pnpm|yarn)\s+(?:install|add|update|upgrade)\b",
    r"\bdotnet\s+(?:add\s+package|tool\s+install)\b",
    r"\bcargo\s+(?:install|add)\b",
    r"\bgo\s+(?:install|get)\b",
]
if tool in {"bash", "powershell"} and matches_any(cmd, ASK_NETWORK):
    ask("Network access or software/dependency installation requires explicit approval.")

# Common download-and-execute patterns: deny, not merely ask.
if tool in {"bash", "powershell"} and matches_any(cmd, [
    r"\b(?:curl|wget)\b[^\n]*(?:\||\$\(|`)[^\n]*(?:sh|bash|zsh|python|perl|ruby)",
    r"\birm\b[^\n]*\|\s*iex\b",
    r"\binvoke-restmethod\b[^\n]*\|\s*invoke-expression\b",
    r"\binvoke-webrequest\b[^\n]*\|\s*invoke-expression\b",
]):
    deny("Blocked download-and-execute command.")

# ---------------------------------------------------------------------------
# Bypass / arbitrary interpreter-based mutation
# ---------------------------------------------------------------------------

# These interpreters are useful, but `-c`/`-e` can trivially bypass command
# blacklists and modify/delete arbitrary files. Ask by default.
if tool in {"bash", "powershell"} and matches_any(cmd, [
    r"\bpython(?:3)?\s+-c\b",
    r"\bperl\s+-e\b",
    r"\bruby\s+-e\b",
    r"\bnode\s+-e\b",
    r"\bphp\s+-r\b",
    r"\bpwsh\b[^\n;&|]*-command\b",
    r"\bpowershell(?:\.exe)?\b[^\n;&|]*-command\b",
    r"\b(?:bash|sh|zsh)\s+-c\b",
]):
    ask("Inline interpreter/shell execution can bypass static guardrails; explicit approval required.")

# Obvious attempts to disable or evade Copilot hooks.
if tool in {"bash", "powershell"} and matches_any(cmd, [
    r"\bdisableallhooks\b",
    r"\bCOPILOT_HOME\b",
    r"\bgithub-copilot\b[^\n]*(?:policy\.d|hooks)",
]):
    deny("Blocked attempt to disable, redirect, or alter Copilot hook enforcement.")

# ---------------------------------------------------------------------------
# Default
# ---------------------------------------------------------------------------

emit("allow")
