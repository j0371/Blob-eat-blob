# Copilot CLI Guardrail

This is an intentionally **over-restrictive** `preToolUse` guardrail for GitHub
Copilot CLI. It is designed to complement `AGENTS.md`, not replace it.

## Files

- `.github/hooks/destructive-operation-guard.json` — repository-level hook config
- `.github/hooks/scripts/pre_tool_guard.py` — enforcement logic

## Behavior

The script returns one of:

- `allow` — ordinary operation
- `ask` — Copilot must request explicit approval
- `deny` — operation is blocked

The starting policy deliberately favors false positives. Review
`pre_tool_guard.py` and remove or narrow rules that interfere with normal work.

It currently targets:

- destructive Git/worktree operations
- history rewriting, ref deletion, reflog/object pruning, force pushes
- commits/pushes/merges/pulls without explicit approval
- file deletion and destructive filesystem commands
- broad overwrite/redirection
- secrets and credential stores
- environment-variable dumping
- privilege escalation and container/host control
- package installation and new network access
- download-and-execute patterns
- attempts to modify/disable the guardrail itself
- inline interpreter commands that can trivially bypass static command matching

## Important limitations

This is defense in depth, not a perfect sandbox.

A repository-level guardrail is weaker than a machine-wide administrator policy:
repository files are part of the working tree, and static command inspection can
never perfectly determine the effect of arbitrary programs.

The Docker containment boundary remains the stronger control for protecting the
host. `AGENTS.md` remains the semantic policy for behavior the hook cannot
reliably infer.

GitHub documents repository hooks under `.github/hooks/*.json`. Copilot CLI
loads hook configuration when the CLI starts, so restart Copilot after changing
the hook configuration.

## Quick test

From the repository root:

```bash
echo '{"timestamp":1704614400000,"cwd":"/workspace","toolName":"bash","toolArgs":{"command":"git status"}}' \
  | python3 .github/hooks/scripts/pre_tool_guard.py

echo '{"timestamp":1704614400000,"cwd":"/workspace","toolName":"bash","toolArgs":{"command":"git reset --hard HEAD"}}' \
  | python3 .github/hooks/scripts/pre_tool_guard.py

echo '{"timestamp":1704614400000,"cwd":"/workspace","toolName":"bash","toolArgs":{"command":"git commit -am test"}}' \
  | python3 .github/hooks/scripts/pre_tool_guard.py
```

Expected decisions: `allow`, `deny`, `ask`.
